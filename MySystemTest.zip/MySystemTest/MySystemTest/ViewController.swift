//
//  ViewController.swift
//  MySystemTest
//
//  Created by SunTelematics on 06/09/17.
//  Copyright © 2017 SunTelematics. All rights reserved.
//

import UIKit
import AVFoundation
import AVKit
import Alamofire

class ViewController: UIViewController {

    @IBOutlet weak var contentTableView: UITableView!
    

    var Content_Data = NSMutableArray()
    
    
    var title_text: String!
    var shortDescription: String!
    var Description : String!
    var videoURL : String!

    
    override func viewDidLoad() {
        super.viewDidLoad()
        contentTableView.estimatedRowHeight = 285
        contentTableView.rowHeight = UITableViewAutomaticDimension

        callService()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func callService() {
        let apikey = "tz6n5M+lnJVw007muIr7UXATrR4quD9V4Z+upTXcDXWzD7LE1eZaHdcyBe/Z3TjChzPdgS5dKvVIQm6gq6HVuw=="
        let articleID = "136"
        let userID = "79"
        
        let postPar = ["api_key_data":"\(apikey)",
            "article_id":"\(articleID)",
            "user_id" :"\(userID)",
            "assesment_id":""]
        
        let urlString = "http://54.251.120.210/DedaaBox_dev/index.php/Articles/article_details"
        let url = URL.init(string: urlString.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!)!
        guard let paramData = try? JSONSerialization.data(withJSONObject: postPar, options: .init(rawValue: 0)) else {
            return
        }
        var Request = URLRequest.init(url: url)
        Request.httpMethod = "POST"
        Request.httpBody = paramData
        Request.allHTTPHeaderFields = ["Content-Type":"application/json"]
        Alamofire.request(Request)
            .responseJSON { (responce) in
                switch responce.result {
                case .success(let Value):
                    let responceData = Value as! NSDictionary
                    //                    print(responceData)
                    
                    let responseObject = responceData.object(forKey: "response") as! NSDictionary
                    //                    print(responseObject)
                    
                    let data = responseObject.object(forKey: "data") as! NSDictionary
                    //                    print(data)
                    let articleData = data.object(forKey: "article_data") as! NSArray
                    for all in articleData{
                        self.Content_Data.add(all)
                        
                    }
                    
                    let i = articleData[0] as! NSDictionary
                    self.title_text = "\(i["title"]!)"
                    self.Description =  "\(i["description"]!)"
                    self.shortDescription = "\(i["short_description"]!)"
                    self.videoURL = "\(i["link"]!)"
                    
                    self.contentTableView.reloadData()
                    break
                case .failure(let error):
                    print(error.localizedDescription)
                    break
                }
        }

    }


}
extension ViewController : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        
        return Content_Data.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
            as! contentCell
        if title_text != nil{
            cell.Title.text = "\(title_text!)"
            cell.shortDescription.text = "\(shortDescription!)"
            cell.Description.text = "\(Description!)"
            
            let videoURL = URL(string: "\(self.videoURL!)")
            let players = AVPlayer(url: videoURL!)
            let playerLayer = AVPlayerLayer(player: players)
            playerLayer.frame = cell.VideoPlayer.bounds
            playerLayer.contentsGravity = kCAGravityResizeAspect
            players.actionAtItemEnd = .none
            cell.VideoPlayer?.layer.addSublayer(playerLayer)
            players.play()
        }
        
        
        cell.Title.sizeToFit()
        cell.shortDescription.sizeToFit()
        cell.Description.sizeToFit()
        return cell
        
    }

}

class contentCell: UITableViewCell {
    @IBOutlet weak var userProfile_image: UIImageView!
    @IBOutlet weak var shortDescription: UILabel!
    @IBOutlet weak var Description: UILabel!
    @IBOutlet weak var Title: UILabel!
    
    @IBOutlet weak var VideoPlayer: UIView!
}
