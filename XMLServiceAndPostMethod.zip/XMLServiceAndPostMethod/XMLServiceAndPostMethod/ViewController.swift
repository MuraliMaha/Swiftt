//
//  ViewController.swift
//  XMLServiceAndPostMethod
//
//  Created by SunTelematics on 06/09/17.
//  Copyright © 2017 SunTelematics. All rights reserved.
//

import UIKit
import Alamofire

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        callService()
    }

    func callService (){
       
        let DriveSupervisorBaseURL = "url...."
        let LoginAPI = "Login"
        
        
        
        var xmlMessage = "<\(LoginAPI) xmlns= 'http://tempuri.org/' >"
        for (key,value) in inputDict {
            xmlMessage.append("<\(key)>\(value)</\(key)>")
        }
        xmlMessage.append("</\(LoginAPI)>")
        print("xmlMessage = \(xmlMessage)")
        
        // need to replace double quotes  of XML text that exist in webportal with single quotes
        let fullXMLMessage = "<?xml version='1.0' encoding='utf-8'?> <soap12:Envelope xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' xmlns:xsd='http://www.w3.org/2001/XMLSchema' xmlns:soap12='http://www.w3.org/2003/05/soap-envelope'><soap12:Body> \(xmlMessage) </soap12:Body></soap12:Envelope>"
        let soapLenth = String(fullXMLMessage.characters.count)
        let theURLString = DriveSupervisorBaseURL
        let theURL = URL(string : theURLString)
//        let mutableReq = NSMutableURLRequest(url: theURL!)
        var Request = URLRequest.init(url: theURL!)
        
        Request.addValue("application/soap+xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        Request.addValue(soapLenth, forHTTPHeaderField: "Content-Length")
        Request.httpMethod = "POST"
        
        
        Request.httpBody = fullXMLMessage.data(using: String.Encoding.utf8)

        Alamofire.request(Request)
            .responseJSON { (responce) in
                switch responce.result {
                case .success(let Value):
                    let responceData = Value as! NSDictionary
                    let dataArr = responceData.object(forKey: "data") as! NSArray
                    print("Sucess")
                    
                    
                 
                    break
                case .failure(let error):
                    print(error.localizedDescription)
                    
                    //as some string is appended with jsonresponse,ctrl comes here.we handled by following lines
                    if (responce.response != nil) {
                        
                        if (responce.response?.statusCode)! == 200 {
                            
                            let ResponseStr = String.init(data: responce.data!, encoding: .utf8)
                            let arr = ResponseStr?.components(separatedBy: "<")
                            let finStr = arr?[0]
                            
                            if let FinalData = finStr?.data(using: .utf8) {
                                if let JsonDict:[String:AnyObject] = try? JSONSerialization.jsonObject(with: FinalData, options: .allowFragments) as! [String:AnyObject] {
                                    print(JsonDict)
                                }
                                else {
                                    
                                }
                            }
                            else {
                                
                            }
                        }
                    }
                    
                    

                    
                    
                    break
                }
        }
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

