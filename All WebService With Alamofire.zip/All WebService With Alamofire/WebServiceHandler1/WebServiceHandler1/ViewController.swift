//
//  ViewController.swift
//  WebServiceHandler1
//
//  Created by SunTelematics on 28/06/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import UIKit
import Alamofire

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()

    }


 
    
    
    //MARK:- SOAP 1.1
    @IBAction func soap1_1BtnTapped(_ sender: UIButton) {
        if (Alamofire.NetworkReachabilityManager()?.isReachable)! {
            
            let requestDict = ["CancelType":"1","RequestId" : "100","DateTime": "2018-june","EmpCode":"hp1030"]
            
            WebServiceClass().SOAP1_1WebServiceMethod(suffix: "CancelRequest", parameterDict: requestDict) { (ResponseDict, ResponseStatus) in
                
                if ResponseStatus {
                    
                    let fullResponse = ResponseDict as! [String:AnyObject]
                    print("fullResponse =",fullResponse)
                    
                    if let data = fullResponse["data"] as! [[String:AnyObject]]? {
                        print("data = ",data)
                    }
                        
                    else {
                        print("ResponseDict not assigned to Dict - failure")
                    }
                }
                else {
                    print("ResponseStatus is false")
                }
                
            }
        }
        else {
            print("Net Error")
        }
    }
    
    //MARK : - SOAP 1.2
    @IBAction func soap1_2BtnTapped(_ sender: UIButton) {
        if (Alamofire.NetworkReachabilityManager()?.isReachable)! {
            
            let requestDict = ["CancelType":"1","RequestId" : "100","DateTime": "2018-june","EmpCode":"hp1030"]
            
            WebServiceClass().SOAP1_2WebServiceMethod(suffix: "CancelRequest", parameterDict: requestDict) { (ResponseDict, ResponseStatus) in
                
                if ResponseStatus {
                    
                    let fullResponse = ResponseDict as! [String:AnyObject]
                    print("fullResponse =",fullResponse)
                    
                    if let data = fullResponse["data"] as! [[String:AnyObject]]? {
                        print("data = ",data)
                    }
                        
                    else {
                        print("ResponseDict not assigned to Dict - failure")
                    }
                }
                else {
                    print("ResponseStatus is false")
                }
                
            }
        }
        else {
            print("Net Error")
        }
    }
    
   
   
    //MARK: - HTTP GET
    @IBAction func HTTP_GET_BtnTapped(_ sender: UIButton) {
        if (Alamofire.NetworkReachabilityManager()?.isReachable)! {
            
            let requestDict = ["CancelType":"1","RequestId" :"100","DateTime": "2018-june","EmpCode":"hp1030"]
            
            WebServiceClass().HTTP_GET_WebServiceMethod(suffix: "CancelRequest", parameterDict: requestDict) { (ResponseDict, ResponseStatus) in
                
                if ResponseStatus {
                    
                    let fullResponse = ResponseDict as! [String:AnyObject]
                    print("fullResponse =",fullResponse)
                    
                    if let data = fullResponse["data"] as! [[String:AnyObject]]? {
                        print("data = ",data)
                    }
                        
                    else {
                        print("ResponseDict not assigned to Dict - failure")
                    }
                }
                else {
                    print("ResponseStatus is false")
                }
                
            }
        }
        else {
            print("Net Error")
        }
    }
    //MARK: - HTTP POST
    @IBAction func HTTP_POST_BtnTapped(_ sender: UIButton) {
        if (Alamofire.NetworkReachabilityManager()?.isReachable)! {
            
            let requestDict = ["CancelType":"1","RequestId" :"100","DateTime": "2018-june","EmpCode":"hp1030"]
            
            WebServiceClass().HTTP_POST_WebServiceMethod(suffix: "CancelRequest", parameterDict: requestDict) { (ResponseDict, ResponseStatus) in
                
                if ResponseStatus {
                    
                    let fullResponse = ResponseDict as! [String:AnyObject]
                    print("fullResponse =",fullResponse)
                    
                    if let data = fullResponse["data"] as! [[String:AnyObject]]? {
                        print("data = ",data)
                    }
                        
                    else {
                        print("ResponseDict not assigned to Dict - failure")
                    }
                }
                else {
                    print("ResponseStatus is false")
                }
                
            }
        }
        else {
            print("Net Error")
        }
    }
    //MARK: - Json Input
    @IBAction func JsonInputBtnTapped(_ sender: UIButton) {
        if (Alamofire.NetworkReachabilityManager()?.isReachable)! {
            
            let RequestDict = ["MobileNo":"7896543211","EmpId":"214672","VendorId":"1287","CorporateId":"10811","AppCustomerType":"2"]
            
            WebServiceClass().jsonInputWebServiceMethod(suffix: "BookingsHistory", parameterDict: RequestDict) { (ResponseDict, ResponseStatus) in
                
                
                if ResponseStatus {
                    
                    let fullResponse = ResponseDict as! [String:AnyObject]
                    print("fullResponse =",fullResponse)
                    
                    if let Table = fullResponse["Table"] as! [[String:AnyObject]]? {
                        print("Table = ",Table)
                    }
                        
                    else {
                        print("ResponseDict not assigned to Dict - failure")
                    }
                }
                else {
                    print("ResponseStatus is false")
                }
            }
            
        }
        else {
            print("No Internet")
        }
        
    }
}

