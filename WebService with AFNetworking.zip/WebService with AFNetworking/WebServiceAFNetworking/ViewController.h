//
//  ViewController.h
//  WebServiceAFNetworking
//
//  Created by SunTelematics on 30/06/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
