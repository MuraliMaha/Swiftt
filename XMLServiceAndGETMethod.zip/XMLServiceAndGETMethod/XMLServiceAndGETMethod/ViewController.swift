//
//  ViewController.swift
//  XMLServiceAndGETMethod
//
//  Created by SunTelematics on 06/09/17.
//  Copyright © 2017 SunTelematics. All rights reserved.
//

import UIKit
import Alamofire


class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        callService()
    }

    func callService() {

//        http://drivee.in/drivesupervisorapp/Drivesupervisorservicev2.asmx/Login?cmd=$DriveLogin|janani|janani@123|EB2BAEAB-B519-40F5-A03F-81386DD16C3C|1|
        
        var inputStr = "$DriveLogin|" + "janani" + "|" + "janani@123"
        let deviceIMEI = UIDevice.current.identifierForVendor?.uuidString
        let deviceToken = "1"
        inputStr.append("|" + deviceIMEI! + "|" + deviceToken + "|#")
        print("Login CMD = " + inputStr)

        let DriveSupervisorBaseURL = "http://drivee.in/drivesupervisorapp/Drivesupervisorservicev2.asmx/"
        let LoginAPI = "Login?cmd="
        let parameter = DriveSupervisorBaseURL + LoginAPI + inputStr
        print("parameter = \(parameter)")

        let theURLString = parameter
         let theURL = URL.init(string: theURLString.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!)!
        var Request = URLRequest.init(url: theURL)
        Request.httpMethod = "GET"
        
        
        Alamofire.request(Request)
            .responseJSON { (responce) in
                switch responce.result {
                case .success(let Value):
                    let responceData = Value as! NSDictionary
                    let dataArr = responceData.object(forKey: "data") as! NSArray
                    print("Sucess")
                    
                    
                    
                    break
                case .failure(let error):
                    print("The error = \(error.localizedDescription)")
                    
                    //as some string is appended with jsonresponse,ctrl comes here.we handled by following lines
                    if (responce.response != nil) {
                        
                        if (responce.response?.statusCode)! == 200 {
                            
                            let ResponseStr = String.init(data: responce.data!, encoding: .utf8)
                            let arr = ResponseStr?.components(separatedBy: "<")
                            let finStr = arr?[0]
                            
                            if let FinalData = finStr?.data(using: .utf8) {
                                if let JsonDict:[String:AnyObject] = try? JSONSerialization.jsonObject(with: FinalData, options: .allowFragments) as! [String:AnyObject] {
                                    print(JsonDict)
                                }
                                else {
                                    
                                }
                            }
                            else {
                                
                            }
                        }
                    }
                    
                    
                    
                    
                    
                    break
                }
        }

        
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

